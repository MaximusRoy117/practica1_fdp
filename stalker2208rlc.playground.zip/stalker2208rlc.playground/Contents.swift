import UIKit

var str = "Hello, playground"

struct Posicion{
    var altitud=0
    var longitud=0
    var latitud=0
    func printData(){
        print("Her position is \(altitud), \(longitud), \(latitud)")
    
    }
}

let gps = Posicion()
print(gps)


