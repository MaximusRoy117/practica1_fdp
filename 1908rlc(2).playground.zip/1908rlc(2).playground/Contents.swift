import UIKit

var str = "Hello, playground"

//func nombreFuncion (Parametros) -> tipopDeRetorno
//{
//
//}

func imprimePi()
{
    print("3.1416")
}

imprimePi()

func doble(valor:Int){
    let resultado = valor * 2
    print("El doble de \(valor) es \(resultado)")
}

doble(valor: 5)

func multiplicacion(primerNumero: Int, segundoNumero: Int){
    let resultado = primerNumero * segundoNumero
    print("El resultado de la multiplicacion de \(primerNumero) X \(segundoNumero) es \(resultado)")
}

multiplicacion(primerNumero: 3, segundoNumero: 5)

func suma(primerNumero:Int, segundoNumero:Int) -> Int {
    return primerNumero + segundoNumero
}

print(suma(primerNumero: 5, segundoNumero: 7))

func devuelveNombre (nombre:String, APaterno:String){
    print("Tu nombre es \(nombre) \(APaterno)")
}

devuelveNombre(nombre: "Valentín", APaterno: "Elizalde")

func diHola(a persona:String, and otraPersona:String){
    print("hola \(persona) y \(otraPersona)")
}

diHola(a: "shazam", and: "fausto")

func resta(_ minuendo:Int, _ sustraendo:Int){
    print("la resta es \(minuendo-sustraendo)")
}

resta(7, 2)

func display(teamName:String, score:Int=0){
    print("\(teamName) : \(score)")
}

display(teamName: "Tamaiti", score:100)
display(teamName: "ALLUNAM")

let randomnum = arc4random_uniform(UInt32(5))

func bolaMagica(){
    switch randomnum {
    case 1:
        print("\(randomnum) : "Siga participando")
            case 2:
            print("\(randomnum) : "Siga participando")
            case 3:
            print("\(randomnum) : "Siga participando")
            case 4:
            print("\(randomnum) : "Siga participando")
            
            }
            }
            
            bolaMagica()


