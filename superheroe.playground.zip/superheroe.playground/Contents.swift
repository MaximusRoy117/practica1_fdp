import UIKit

var str = "Hello, playground"

class Superhero{
    var name = ("")
    var health = 0
    var position = 0
    func derecha(){
        position+1
    }
    func izquierda(){
        position-1
    }
}

let spiderman = Superhero()
print("\(spiderman.position)")

