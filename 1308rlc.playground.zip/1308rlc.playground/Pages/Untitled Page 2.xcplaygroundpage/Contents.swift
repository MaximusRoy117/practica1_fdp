//: [Previous](@previous)

import Foundation
var temperature = 100;
let statement = temperature >= 100;
if(/*statement*/ temperature >= 100)
{
    print("The water is boiling");
}
else
{
    print("The water is not boiling");
}

var snowing = false;

if (!snowing)
{
    print("Do you want to build a snowman?");
}

temperature = 21;

if (temperature >= 18 && temperature <= 25)
{
    print("Good weather");
}

var plugged = false;
var charged = false;

if (plugged || charged)
{
    print("Available :D");
}
else
{
    print("Not available XoX");
}

let wheels = 6;

switch wheels
{
case 1:
    print("Monocicle");
case 2:
    print("Bicicle");
case 3:
    print("Tricicle");
case 4:
    print("Mongoose");
default:
    print("It has more than 4 wheels.");
}

let chrctr =  "z";

switch chrctr
{
case "a", "e", "i", "o", "u":
    print("Vowel");
default:
    print("Consonant");
}

let steps = 316;

switch steps {
case 250...300:
    print("You're a tall.")
case 301...350:
    print("Average height.");
case 351...500:
    print("Greetings, rat raider.");
case Int.min...249:
    print("You're a titan.")
default:
    print("You don't need to go there.");
}

//: [Next](@next)
