import UIKit

var str = "Hello, playground"

let greetings = "hello";

var anotherGreeting = "Hey there";

let questionAnswer = """
Q: What is obo?
A: This one!
"""

print(questionAnswer);

let moreGreetings = "This is an example of screenshot \\ \r \t \"Hello world\""

print(moreGreetings);

let myString = "";

if(myString.isEmpty)
{
    print("This string is empty");
}

let a = "a"; //a is a string of characters
let b:Character = "b"; //This is just one character

let string1 = "Hello";
let string2 = ", world. ";

var myStringConcat = string1 + string2;

print(myStringConcat);

myStringConcat += myStringConcat;

print(myStringConcat);

let name = "Rodrigo";
let edad = "19";

print("\(name) has \(edad)");

let c:Int = 5;
let d:Int = 7;

print("The add of \(c) plus \(d) is \(c+d)");


