import UIKit

var str = "Hello, playground"

struct Person{
    var name:String
    var age:Int
    
    func sayHi(){
        print("Hi, my name is \(name) and I have \(age) years")
    }
}

let person = Person(name: "Rodrigo", age: 19)

print(person.name)
print(person.age)
print("\(person.name) has \(person.age) years ")
person.sayHi()

struct Velocimetro{
    var velocidad: Int = 0
}

let velocimetro = Velocimetro()
print(velocimetro.velocidad)

let velocimetroVocho = Velocimetro(velocidad:5)

print(velocimetroVocho.velocidad)

struct Temperatura{
    var centigrados:Double
    
    init(centigrados:Double){
        self.centigrados=centigrados
    }
    
    init(fahrenheit:Double){
        centigrados=(fahrenheit-32)/1.8
    }
}

let temperaturaCDMX=Temperatura(centigrados: 22.5)
let temperaturaAcapulco=Temperatura(fahrenheit: 84)

print(temperaturaAcapulco.centigrados)
