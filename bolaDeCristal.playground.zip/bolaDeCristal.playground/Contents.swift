import UIKit

var str = "Hello, playground"

let randomnum = arc4random_uniform(UInt32(5))

func bolaMagica(){
    switch randomnum {
    case 1:
        print("Keep trying")
    case 2:
        print("Better that the worst")
    case 3:
        print("Almost there")
    case 4:
        print("Nice job")
    default:
        break
    }
}

bolaMagica()
